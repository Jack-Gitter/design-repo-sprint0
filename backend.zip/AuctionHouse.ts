import AuctionFloor from './AuctionFloor'

 export default interface AuctionHouse {  // extends interctableArea
		 auctionFloors: AuctionFloor[] 
		 //handleCommand (inherited) 
		 //getType() required for the toModel() method
         //static fromMapObject(mapObject: ITiledMapObject, broadcastEmitter: TownEmitter): MuseumArea // for creating a Museum A
 }
