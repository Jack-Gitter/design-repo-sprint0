import { Artwork } from './Artwork'
export default class Player {

		private authtoken: string;
		private net_worth: number;
		private art: Artwork[];

}
